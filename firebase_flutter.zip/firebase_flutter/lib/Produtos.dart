import 'package:uuid/uuid.dart';
//Classe para trabalhar com objetos de Produtos

class Produto {
  //Atributos da classe (iguais aos do banco de dados)
  String _id;
  String _produto;
  String _preco;
  String _qtde;
  static Produto produtoEditar; //Atributo usado na edição

  //Construtor
  Produto(String produto, String preco, String qtde){
    this._id = Uuid().v4();
    this._produto = produto;
    this._preco = preco;
    this._qtde = qtde;
  }

  //Construtor nomeado para edição de dados
  Produto.editar(String id, String produto, String preco, String qtde){
    this._id = id;
    this._produto = produto;
    this._preco = preco;
    this._qtde = qtde;
  }

  //Construtor nomeado que converte json para objeto
  Produto.fromJson(Map<dynamic, dynamic> json)
      : _id = json['id'],
        _produto = json['produto'],
        _preco = json['preco'],
        _qtde = json['qtde'];

  //Método que de um objeto do tipo Produto retorna um Map (json)
  Map<dynamic, dynamic> toJson() => {
    'id': _id,
    'produto': _produto,
    'preco': _preco,
    'qtde': _qtde,
  };

  //Getter e Setters da classe
  String get qtde => _qtde;

  set qtde(String value) {
    _qtde = value;
  }

  String get preco => _preco;

  set preco(String value) {
    _preco = value;
  }

  String get produto => _produto;

  set produto(String value) {
    _produto = value;
  }

  // ignore: unnecessary_getters_setters
  String get id => _id;

  // ignore: unnecessary_getters_setters
  set id(String value) {
    _id = value;
  }

  //Método toString sobrescrito para a saída (output) de dados.
  @override
  String toString() {
    return 'Id: $_id, Produto: $_produto, Preço: $_preco, Quantidade: $_qtde';
  }
}