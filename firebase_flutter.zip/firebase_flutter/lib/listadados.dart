import 'package:firebase/firebase.dart';
import 'package:flutter/material.dart';
import 'firebase_db.dart';
import 'MyHomePage.dart';
import 'Produtos.dart';
import 'FirebaseCustom.dart';

// @dart=2.9

class MyListData extends StatefulWidget {
  const MyListData({Key key}) : super(key: key);

  @override
  _MyListDataState createState() => _MyListDataState();
}

class _MyListDataState extends State<MyListData> {
  String path = "produtos";
  int numItens;

  @override
  void initState() {
    getListaProdutos();
    super.initState();
  }

  Future<List> getListaProdutos() async {
    List<Produto> listaProdutos = [];
    DatabaseReference dataRef = Fire.database.ref(path);
    List data = await getList(dataRef);
    numItens = data.length;
    for(int i=0; i<data.length; i++) {
      DataSnapshot dadoAtual = data[i];
      Produto prod = Produto.fromJson(dadoAtual.toJson());
      listaProdutos.add(prod);
    }
    return listaProdutos;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: getListaProdutos(),
      builder: (context, snapshot){
        if (snapshot.connectionState != ConnectionState.done) {
          return Center(
            child: Container(
              width: 50,
              height: 50,
              child: CircularProgressIndicator(
                  backgroundColor: Colors.blue
              ),
            ),
          );
        } else {
          return Scaffold(
            body: ListView.builder(
                itemCount: numItens,
                itemBuilder: (context, value) {
                  return ListTile(
                      title: Text(snapshot.data[value].produto ?? "default"),
                      subtitle: Text("R\$ ${snapshot.data[value].preco}\n"
                          "Estoque: ${snapshot.data[value].qtde}" ?? "default"),
                      isThreeLine: true,
                      trailing: ElevatedButton(
                        child: Icon(Icons.delete_outline),
                        //Chamada da função delete...
                        onPressed: (){
                            FirebaseDB.firebaseDbInstance.deleteValue(
                              snapshot.data[value].id
                            );
                            //Atualizar a tela
                            setState(() {
                              getListaProdutos();
                            });
                          },
                      ),
                      onLongPress: (){
                        //Chamada da função update...
                        Produto.produtoEditar = snapshot.data[value];
                        Navigator.push(context, MaterialPageRoute(
                            builder: (context)=>MyHomePage()));
                        //Atualizar a tela
                        setState(() {
                          getListaProdutos();
                        });
                      }
                  );
                }
            )
          );
        }
      }
    );
  }
}