import 'package:firebase/firebase.dart' as fb;
import 'package:firebase/firebase.dart';

class FirebaseHelper{
  static fb.Database initDatabase() {
    try{
      if(fb.apps.isEmpty){
        fb.initializeApp(
          apiKey: "AIzaSyDhrBQvtFPcWCRw2GKQssD9kK44tsnUNKc",
          authDomain: "testecrud-b3e13.firebaseapp.com",
          databaseURL: "https://testecrud-b3e13-default-rtdb.firebaseio.com",
          projectId: "testecrud-b3e13",
          storageBucket: "testecrud-b3e13.appspot.com",
          messagingSenderId: "818428123933",
          appId: "1:818428123933:web:12eb786703af8f64ec1ff4",
          measurementId: "G-Y882JXZSNL"
        );
      }
    } on fb.FirebaseJsNotLoadedException catch (e){
      print(e);

    }
    return fb.database();
  }
}

class Fire {
  static fb.Database database = FirebaseHelper.initDatabase();
}

Future<String> getOnce(fb.DatabaseReference AdsRef) async {
  String aux;
  await AdsRef.once('value').then((value) => {aux = value.snapshot.val()});
  return aux;
}

Future<List> getList(fb.DatabaseReference AdsRef) async {
  List list = [""];
  await AdsRef.once('value')
      .then((value) => {list = result(value.snapshot, list)});
  return list;
}

List result(DataSnapshot dp, List list) {
  list.clear();
  dp.forEach((v) {
    list.add(v);
  });
  return list;
}