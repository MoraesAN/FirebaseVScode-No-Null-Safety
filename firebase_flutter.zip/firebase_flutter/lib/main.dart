import 'package:flutter/material.dart';
import 'MyHomePage.dart';
import 'FirebaseCustom.dart';

void main() {
  FirebaseHelper.initDatabase();
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: MyHomePage(),
  ));
}
